var x=10;
var y=20;
var z=(x+y)*30;
console.log(z);
var math=require('mathjs');//internal module to perform cimplex mathematical operations
math.pow(2,3);