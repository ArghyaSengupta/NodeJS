var events = require('events');// using in built module events
var eventEmitter = new events.EventEmitter();//es6(ecmascript version 6)

//Create an event handler:lts(long time support)
var myEventHandler = function () {
  console.log('I hear a scream!');
}

var myEventHandler1 = function () {
  console.log('I hear a scream2!');
}

//Assign the event handler to an event:
eventEmitter.on('scream', myEventHandler);

eventEmitter.on('scream2', myEventHandler1);

//Fire the 'scream' event:
eventEmitter.emit('scream');

eventEmitter.emit('scream2');